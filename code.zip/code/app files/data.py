import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
from auxiliary import save_pickle, load_pickle

# Путь к директории с данными
DATA_PATH = "./data/"

def generate_dataset(N=1000, c_val=0.5, r=1/np.sqrt(2*np.pi)):
    """
    Функция для генерации обучающих и тестовых данных
    Точки генерируются равномерно в интервале [0,1]². 
    Им будет присвоена метка 1, если они находятся внутри круга с радиусом r и центром c_val
    Входные параметры:
        N (int):         число точек (экземпляров, образцов) данных
        c_val (float):   центр круга
        r (float):       радиус круга
    Возвращаемые значения:
        X_train (np.ndarray [Nx2]):     обучающие образцы
        Y_train (np.ndarray [Nx1]):     метки к обучающим образцам
        X_test (np.ndarray [Nx2]):      тестовые образцы 
        Y_test (np.ndarray [Nx1]):      метки к тестовым образцам
    """
    # Случайным образом сгенерировать обучающие образцы набора данных
    X = np.random.uniform(0, 1, (N * 2, 2))
    
    # Получить метки: вычесть центр и вычислить норму
    Y = (np.linalg.norm(X - c_val, axis=1) <= r).astype(int)
    Path(DATA_PATH).mkdir(exist_ok=True)
    
    # Разбить данные на обучающие и тестовые и сохранить в pickle-файлах
    save_pickle(X[:N], DATA_PATH + "X_train.pickle")
    save_pickle(Y[:N], DATA_PATH + "Y_train.pickle")
    save_pickle(X[N:], DATA_PATH + "X_test.pickle")
    save_pickle(Y[N:], DATA_PATH + "Y_test.pickle")
    
    # Вывести данные на графике
    #plt.plot(X[:,0][Y == 0], X[:, 1][Y == 0], 'g^')  # зеленые треугольники
    #plt.plot(X[:,0][Y == 1], X[:, 1][Y == 1], 'bs')  # синие квадраты
    #plt.show()
    
    # Вернуть обучающие и тестовые выборки и метки к экземплярам данных
    return X[:N], Y[:N], X[N:], Y[N:]
