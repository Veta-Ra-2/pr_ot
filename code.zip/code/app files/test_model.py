from data import generate_dataset
from networks import NeuralNetwork
from layers import LinearLayer, ReLULayer, TanhLayer, SigmoidLayer, LeakyReLULayer, SwishLayer
from loss_functions import MSELoss
from auxiliary import calc_perf, plot_data, plot_history, early_stopping, load_pickle
import numpy as np

np.random.seed(0)

# Путь к директории с файлом модели
MODEL_PATH = "./models/"

def train_nn_model(inputs_n = 2, outputs_n = 1, hidden_layers_n = 3,
            hidden_neurons_n = [25, 25, 25], act_funcs = [2, 6, 3],
            l_rate = 0.0001, tr_epochs = 500, early_stop_n = 3, 
            save_weight = True, plot_hist = True, verbose = False):
    """
    Основная функция, которая, принимая на вход параметры 
    нейронной сети, выполняет следующие действия:
     * генерирует обучающие и тестовые данные
     * инициализирует нейронную сеть
     * обучает нейронную сеть
    
    Входные параметры:
        inputs_n (int):               Число входных сигналов
        outputs_n (int):              Число выходных сигналов
        hidden_layers_n (int):        Число скрытых слоев
        hidden_neurons_n (list):      Число нейронов на каждом скрытом слое
        act_funcs (list):             Слои активации для каждого скрытого слоя (закодированы как числа от 1 до 6)
                                       1: линейная функция активации
                                       2: ReLU
                                       3: гиперболический тангенс
                                       4: сигмоидальная функция активации
                                       5: ReLU с утечкой
                                       6: Swish-функция
        l_rate (float):               Скорость обучения
        tr_epochs (int):              Число эпох обучения
        early_stop_n (int):           Число эпох для ранней остановки
        save_weight (bool):           Сохранять веса модели или нет
        plot_hist (bool):             Строить графики результатов обучения или нет
        verbose (bool):               Вывод сведеинй об обучении в консоль

    Возвращаемое значение:
        network (NeuralNetwork):      Обученная нейронная сеть
    """
    print("Обучение.")

    # Список слоев с функциями активации
    act_layers = [LinearLayer, ReLULayer, TanhLayer, SigmoidLayer, LeakyReLULayer, SwishLayer]

    # Список используемых слоев согласно выбранным функциям активации
    used_layers = [act_layers[i-1] for i in act_funcs]

    # Слить входы, выходы и число нейронов на каждом скрытом слое в одну структуру - список используемых нейронов
    used_neurons = [inputs_n] + hidden_neurons_n + [outputs_n]

    # Создать список из используемых слоев при помощи списка используемых нейронов 
    # (добавить входные и выходные нейроны на каждый слой)
    initialize_layers = [layer_c(used_neurons[i], used_neurons[i+1]) for i, layer_c in enumerate(used_layers)]
    
    # Добавить выходной слой сети (последний слой - линейный; входные сигналы - предпоследние используемые нейроны в списке, 
    # выходные – последние используемые нейроны в списке используемых нейронов)
    initialize_layers += [LinearLayer(used_neurons[-2], used_neurons[-1])]

    # Построить модели нейронной сети при помощи последнего списка слоев (initialize_layers)
    network = NeuralNetwork(layers = initialize_layers)

    # Сгенерировать обучающие и тестовые данные
    X_train, Y_train, X_test, Y_test = generate_dataset()

    # Инициализировать среднеквадратическую функцию потерь (MSE)
    MSE = MSELoss()

    # Создать списки для хранения значений MSE и accuracy на обучающей и тестовой выборке
    train_mse = []
    train_accs = []
    test_mse = []
    test_accs = []

    # На каждой эпохе (по числу эпох обучения) выполнить:
    for epoch in range(tr_epochs):

        # Создать списки MSE / accuracy для текущей эпохи
        epoch_mse = []
        epoch_acc = []

        # Для всех экземпляров обучающей выборки выполнить:
        for x, y in zip(X_train, Y_train):
            ##### Обучение
            # Получить отклик сети (выполнить прямое распространение)
            out_value = network.forward(x.reshape((2,1)))

            # Определить, был ли отклик сети верным и добавить результат в accuracy-список:
            label = 1 if out_value >= 0.5 else 0
            right = int(y == label)
            epoch_acc.append(right)

            # Вычислить значение MSE и добавить в MSE-список
            mse_err = MSE(y, out_value)
            epoch_mse.append(mse_err)

            # Вычислить ошибку, полученную в результате обратного распространения по сети
            error = MSE.backward()

            # Выполнить обратное распространение ошибки (обновить веса сети)
            network._backpropagation(error)
            network._update_weights(l_rate)

        # Вычислить среднее значение accuracy и MSE для этой эпохи и сохранить их
        train_mse.append((epoch, np.mean(epoch_mse)))
        train_accs.append((epoch, np.mean(epoch_acc)))

        # Если необходимо выводить результаты обучения, то выполнить это для каждой десятой эпохи 
        if verbose and epoch % 10 == 0:
            print(f"[*Обучение*] Эпоха {epoch:4} |   MSE: {train_mse[-1][1]:2.3f} | Accuracy: {train_accs[-1][1]:1.3f}")
        
        # Вычислить MSE и accuracy на тестовых данных
        mse_err, accuracy, predictions = calc_perf(X_test, Y_test, network)
        
        # Сохранить их в соответствующие списки
        test_mse.append((epoch, mse_err))
        test_accs.append((epoch, accuracy))

        ##### Выполнить проверку ранней остановки
        if early_stopping(test_mse, n = early_stop_n):
            break

    if save_weight:
        # Сохранить веса модели в файл
        network._save_model(MODEL_PATH)

    if plot_hist:
        # Вывести графики результатов обучения модели
        plot_history(train_mse, train_accs, test_mse, test_accs)

    print("Обучение окончено!")

    return network

def test_nn_model(network = None):
    """
    Функция для оценки производительности сети на тестовых данных. 
    Если сеть явно не указана, функция пытается инициализировать сеть из сохраненной модели.

    Входные параметры:
        network (NeuralNetwork):    Объект NeuralNetwork для оценки
    """
    print("Тестирование.")
    
    # Выполнить чтение тестовых данных из pickle-файлов
    X_test = load_pickle('./data/X_test.pickle')
    Y_test = load_pickle('./data/Y_test.pickle')

    # Проверить, была ли явно указана сеть. Если нет, то
    if not network:
        # загрузить сеть из сохраненного pickle-файла модели
        network = NeuralNetwork(load_s_weights = True, model_fp = MODEL_PATH + "model.pickle")

    # Рассчитать основные метрики
    mse_err, accuracy, predictions = calc_perf(X_test, Y_test, network)
    
    # Вывести результаты тестирования
    print(f"Тестирование окончено с accuracy = {accuracy:.2f} и MSE = {mse_err:.2f}")

if __name__=="__main__":
    trained_network = train_nn_model()
    test_nn_model(trained_network)
